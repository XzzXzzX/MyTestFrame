import AssetManager from "../core/manager/AssetManager";
import UIManager from "../core/manager/UIManager";
import { ModuleTypes } from "../core/data/CommonEnumTypes";
import { printzx } from "../util/AppLog";
import { PBBuild } from "../core/proto/PBBuild";
import SocketManager from "../core/manager/SocketManager";
import { ViewType } from "../core/data/ViewType";
import TestModule from "../TestModule";


const {ccclass, property} = cc._decorator;

@ccclass
export default class TestScene extends cc.Component {

    @property(cc.Node)
    btnConnect: cc.Node = null;

    @property(cc.Node)
    btnSend: cc.Node = null;

    @property(cc.Node)
    btnTest: cc.Node = null;


    ws: WebSocket = null;

    onLoad()
    {

    }

    start()
    {
        // 加载pb文件
        PBBuild.init();

        // 创建websocket
        SocketManager.getInstance().createSocket("ws://127.0.0.1:8888");

        let module: TestModule = new TestModule();

        this.addEvent();
        AssetManager.getInstance().preLoadAsset(ModuleTypes.PhysicWorld, (cur, total)=>{
            //加载进度
            // printzx("zx_ load process: " + cur + "/" + total);
        }, ()=>{
            // 打开物理界面
            UIManager.getInstance().showView(ViewType.PhysicsView, {bStatic:true});
        });
    }

    private addEvent(): void
    {
        this.btnConnect.on("click", this.onConnectClick, this);
        this.btnSend.on("click", this.onSendClick, this);
        this.btnTest.on("click", this.onTestClick, this);
    }

    private onConnectClick(): void
    {
        if (null != this.ws)
        {
            return;
        }
        let wsUrl: string = "ws://127.0.0.1:8888";
        this.ws = new WebSocket(wsUrl);
        this.ws.onopen = this.onSocketOpen;
        this.ws.onmessage = this.onSocketMsg;
        this.ws.onerror = this.onSocketErr;
        this.ws.onclose = this.onSocketClose;

        // alert("");
    }

    private onSendClick(): void
    {
        // this.ws.send("this is client");


        let ts: any = PBBuild.encodePB("proto/TestPB", "WSMessage");
        ts.setId(123);
        ts.setContent('aa');
        ts.setSender('client');
        ts.setTime('0000');

        let msg: any = PBBuild.encodePB("proto/TestPB", "MsgPB");
        msg.code = 100;
        msg.body = ts.encode().toBuffer();
        this.ws.send(msg.encode().toBuffer());
        // this.ws.send(JSON.stringify(msg));
    }
    
    private onTestClick(): void
    {
        this.ws.close();
    }

    /**
     * websocket连接成功
     */
    onSocketOpen = (msg: MessageEvent)=>
    {
        cc.log("socket open:" , msg);
        // alert("socket open");
    }
    
    /**
     * 接收到服务器返回消息
     */
    onSocketMsg = (msg: MessageEvent)=>
    {
        cc.log("socket msg:" , msg);
        let data: any = msg.data;
        cc.log("msg data: ", data);

        // 服务器返回的protobuf数据被整合为一个blob数据了，
        // 解析blob数据
        var reader = new FileReader();
        reader.readAsArrayBuffer(data);
        // var buf = new Uint8Array(reader.result);
        // let msgBody: any = PBBuild.decodePB("proto/TestPB", "MsgPB");
        // let msgInfo: any = msgBody.decode(buf);
        // cc.log("msginfo: ", msgInfo);
        // let body: any = PBBuild.decodePB("proto/TestPB", "WSMessage");
        // let bodyInfo: any = body.decode(msgInfo.body);
        // cc.log("bodyInfo: ", bodyInfo);

        reader.onload = function (e){
            if (e)
            {
                cc.log(e);
            }
            var buf = new Uint8Array(reader.result);
            
            let msgBody: any = PBBuild.decodePB("proto/TestPB", "MsgPB");
            let msgInfo: any = msgBody.decode(buf);
            cc.log("msginfo: ", msgInfo);
            let body: any = PBBuild.decodePB("proto/TestPB", "WSMessage");
            let bodyInfo: any = body.decode(msgInfo.body);
            cc.log("bodyInfo: ", bodyInfo);
        }
    }

    onSocketErr = (msg: MessageEvent)=>
    {
        cc.log("socket err:" , msg);
        this.ws = null;

    }

    /**
     * 连接关闭
     */
    onSocketClose = (msg: CloseEvent)=>
    {
        cc.log("socket close:" , msg);
        this.ws = null;
    }
}